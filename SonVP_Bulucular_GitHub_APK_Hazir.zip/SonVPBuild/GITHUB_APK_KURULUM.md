# Son VP Bulucular — APK oluşturma

1. GitHub'da boş bir repository oluştur.
2. Bu klasörün içindeki tüm dosyaları repository'ye yükle.
3. GitHub > Actions > Build APK > Run workflow.
4. Build bitince workflow çalışmasına gir.
5. Artifacts bölümünden `SonVP-Bulucular-APK` dosyasını indir.
6. ZIP'i aç ve `app-debug.apk` dosyasını tablette kur.
