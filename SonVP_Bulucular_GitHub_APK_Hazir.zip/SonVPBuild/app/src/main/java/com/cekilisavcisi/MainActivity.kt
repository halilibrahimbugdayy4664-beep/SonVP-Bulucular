package com.sonvpbulucular

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import org.jsoup.Jsoup
import java.net.URLEncoder

data class Giveaway(val title:String, val url:String)

class MainActivity : AppCompatActivity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    override fun onCreate(b: Bundle?) {
        super.onCreate(b); setContentView(R.layout.activity_main)
        val q=findViewById<EditText>(R.id.query)
        findViewById<Button>(R.id.search).setOnClickListener { scan(q.text.toString()) }
        findViewById<Button>(R.id.refresh).setOnClickListener { scan(if(q.text.isBlank()) "çekiliş" else q.text.toString()) }
    }
    private fun scan(raw:String) {
        val query=raw.trim().ifBlank { "çekiliş" }
        findViewById<ProgressBar>(R.id.progress).visibility=View.VISIBLE
        findViewById<LinearLayout>(R.id.results).removeAllViews()
        scope.launch {
            val items=withContext(Dispatchers.IO) { searchWeb(query) }
            findViewById<ProgressBar>(R.id.progress).visibility=View.GONE
            if(items.isEmpty()) addText("Sonuç bulunamadı veya şüpheli sonuçlar elendi.")
            items.forEach { g -> addGiveaway(g) }
        }
    }
    private fun searchWeb(q:String):List<Giveaway> {
        return try {
            val encoded=URLEncoder.encode("$q çekiliş -şifre -kart -ödeme", "UTF-8")
            val doc=Jsoup.connect("https://www.google.com/search?q=$encoded")
                .userAgent("Mozilla/5.0").timeout(10000).get()
            val out=mutableListOf<Giveaway>()
            for(a in doc.select("a")) {
                val href=a.attr("href"); val text=a.text().trim()
                if(text.length<8 || href.isBlank()) continue
                val url=when {
                    href.startsWith("/url?q=") -> href.substringAfter("/url?q=").substringBefore("&")
                    href.startsWith("http") -> href
                    else -> continue
                }
                val low=(text+" "+url).lowercase()
                val bad=listOf("şifre","password","kart bilg","kredi kart","iban","havale","para yatır","ödeme yap","ücretli")
                if(bad.any { low.contains(it) }) continue
                if(url.contains("google.com")) continue
                if(out.none { it.url==url }) out.add(Giveaway(text,url))
                if(out.size>=20) break
            }
            out
        } catch(_:Exception) { emptyList() }
    }
    private fun addGiveaway(g:Giveaway) {
        val box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.setPadding(18,18,18,18)
        val t=TextView(this); t.text="🎁 ${g.title}"; t.textSize=17f; t.setTextColor(-1)
        val b=Button(this); b.text="Siteyi aç"; b.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(g.url)))
            Toast.makeText(this,"Geri dönünce: Katıldın mı?",Toast.LENGTH_LONG).show()
        }
        box.addView(t); box.addView(b)
        findViewById<LinearLayout>(R.id.results).addView(box)
    }
    private fun addText(s:String) {
        val t=TextView(this); t.text=s; t.setTextColor(-1); t.textSize=16f; t.setPadding(8,20,8,20)
        findViewById<LinearLayout>(R.id.results).addView(t)
    }
}
